import { MelodyTransformation } from '../types';

export const doNothing = (m: MelodyTransformation): MelodyTransformation => m;
